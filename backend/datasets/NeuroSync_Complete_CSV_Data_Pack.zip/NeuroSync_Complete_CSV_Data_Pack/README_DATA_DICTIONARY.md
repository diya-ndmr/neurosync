# NeuroSync Complete CSV Data Pack

**As-of date:** 2026-10-24  
**Coverage:** 2026-04-24 through 2026-10-24 (six months, inclusive)  
**Students:** 500  
**Data:** Fully synthetic demo/test data. No real student, lecturer, advisor, or counselling records are included.

## Important integration notes
- `master_student_snapshot.csv` is a convenient one-row-per-student summary for dashboards and initial integration. It does not replace the detailed tables.
- The other CSVs are relational tables. Join on the IDs (e.g. `student_id`, `module_id`, `topic_id`, `referral_id`, `slot_id`, `user_id`).
- `risk_assessments.csv` contains illustrative synthetic risk scores. These are **not validated clinical or academic predictions** and must not be used to make consequential decisions without human review.
- `users_roles.csv` intentionally contains no real passwords or usable password hashes. `password_hash_demo` is a placeholder only. Use your existing authentication provider; never authenticate users from this CSV.
- Wellness bookings are sensitive. Enforce strict role-based access and expose only minimal appointment status to non-Wellness staff.
- CSVs are seed/import data, not a replacement for a production database. For live production, use a database, validation, audit logging, backups, consent controls, and secure authentication.
- Dates use ISO `YYYY-MM-DD`. Timestamps include South African UTC offset `+02:00` where applicable.
- `data_is_synthetic=True` marks generated records.

## Files
| File | Purpose |
|---|---|
| `master_student_snapshot.csv` | One row per student with current profile, last login, recent attendance/marks, risk summary, advisor and referral counts |
| `students.csv` | Student profile and programme |
| `users_roles.csv` | Synthetic staff/student identities and role labels; no usable credentials |
| `modules.csv` | Modules, faculties and assigned lecturer |
| `module_topics.csv` | Topic catalogue for each module |
| `student_module_enrolments.csv` | Student-to-module enrolment links |
| `advisor_assignments.csv` | Advisor caseload assignments |
| `attendance_records.csv` | Dated attendance by student and module |
| `login_activity.csv` | Synthetic login/session events over the six-month period |
| `assessments.csv` | Marks, assessment type, topic and submission status |
| `topic_performance.csv` | Topic-level performance summary and learning status |
| `lecturer_feedback.csv` | Lecturer feedback on specific student/topic combinations |
| `learning_resources.csv` | Resource recommendations/assignments linked to topics and students |
| `risk_assessments.csv` | Recent risk snapshot and indicators |
| `referrals.csv` | Referral source, category, advisor, priority and status |
| `interventions.csv` | Advisor-owned support plans and follow-up dates |
| `wellness_slots.csv` | Appointment slot inventory |
| `wellness_bookings.csv` | Booking status and referral link; sensitive data |
| `student_preferences.csv` | Student themes, layout and notification preferences |
| `notifications.csv` | Student-facing notifications and read status |

**Advisor workflow coverage:** referral and intervention tables include a populated synthetic caseload for testing advisor queues, follow-ups, active interventions, and resolved cases.

## Suggested join keys
- Student data: `student_id`
- Accounts: `user_id` (student IDs match `student_id`)
- Modules: `module_id`; topics: `topic_id`
- Referrals/interventions: `referral_id`
- Wellness inventory/bookings: `slot_id`, `booking_id`, `student_id`
- Advisor and lecturer identities: `advisor_id`, `lecturer_id`, `user_id`

## Integration cautions
1. Inspect the existing NeuroSync schemas before importing. Map fields rather than blindly replacing working tables.
2. CSV import should be idempotent (upsert by stable IDs), validated, and logged.
3. Never expose all student data to every role. Students should only see their own data; lecturers should see their teaching cohorts; advisors should see assigned caseloads; Wellness staff should see restricted Wellness information; admins should follow least-privilege access.
4. Sample login activity is generated test data, not real authentication/audit history.
